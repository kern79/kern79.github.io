function setup() {
  createCanvas(400, 400);
  ellipseMode(CENTER)
  
  
}

function draw() {
  fill(50,100,200);
  stroke(200,230,100);
  strokeWeight(10);
  background (204,0,0);
  ellipse(200,200,240);
  circle(200,150,200);
  square(100,200,200);
  square(20,20,20)
  square(10,10,10)
  square(30,30,30)
  square(40,40,40)
  square(50,50,50)
  square(60,60,60)
  square(70,70,70)
  square(100,100,100)
  
        
        
  
      
  
  
      
}